# Learning Java
1. [Homeworks](https://github.com/enhorse/learningJava/tree/master/src/main/java/xyz/enhorse/javarush) for the course from [Java Rush](http://javarush.ru/)
2. [Homeworks](https://github.com/enhorse/learningJava/tree/master/src/main/java/xyz/enhorse/m101j) for the course [M101J: MongoDB for Java Developers](https://university.mongodb.com/courses/M101J/about)
3. [Homeworks](https://github.com/enhorse/learningJava/tree/master/src/main/java/xyz/enhorse/stepic/algo) for the course [Алгоритмы: теория и практика. Методы](https://stepic.org/course/217)
4. [Homeworks](https://github.com/enhorse/learningJava/tree/master/src/main/java/xyz/enhorse/stepic/djwebservice) for the course [Разработка веб сервиса на Java (часть 1)](https://stepic.org/course/146)
5. [Homeworks](https://github.com/enhorse/learningJava/tree/master/src/main/java/xyz/enhorse/stepic/hadoop) for the course [Hadoop. Система для обработки больших объемов данных](https://stepic.org/course/150)